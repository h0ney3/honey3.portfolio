﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace モグラたたき
{
    public partial class Form2 : Form
    {
        private int playerPoints;
        private string Answer;
        private SoundPlayer seikaiSoundPlayer;
        private SoundPlayer fuseikaiSoundPlayer;
        public Form2()
        {
            InitializeComponent();
            seikaiSoundPlayer = new SoundPlayer("maou_se_system44.wav");
            fuseikaiSoundPlayer = new SoundPlayer("maou_se_system47.wav");
            button1.Click += button_Click;
            button2.Click += button_Click;
            button3.Click += button_Click;
            button4.Click += button_Click;
        }
        public void SetPoints(int points)
        {
            playerPoints = points;
            Quiz();
        }

        private void Quiz()
        {
            string question = string.Empty;
            string[] options = new string[4];


            if (playerPoints >= 24)
            {
                question = "秋の味覚と呼ばれるサツマイモを漢字で書くと？";
                options = new string[] { "薩摩芋", "札真芋", "佐津馬芋", "薩磨芋" };
                Answer = "薩摩芋";
            }
            else if (playerPoints >= 22)
            {
                question = "11月は旧暦で何と呼ばれていたでしょう？";
                options = new string[] { "望月", "霜月", "神無月", "新月" };
                Answer = "霜月";
            }
            else if (playerPoints >= 20)
            {
                question = "この中で一番睡眠時間が長い動物は？";
                options = new string[] { "コアラ", "象", "なまけもの", "くま" };
                Answer = "コアラ";
            }
            else if (playerPoints >= 18)
            {
                question = "猫の血液型は何種類？";
                options = new string[] { "1種類", "２種類", "３種類", "４種類" };
                Answer = "３種類";
            }
            else if (playerPoints >= 16)
            {
                question = "世界一栄養素がないとギネス認定されている野菜は？";
                options = new string[] { "きゅうり", "もやし", "すいか", "レタス" };
                Answer = "きゅうり";
            }
            else if (playerPoints >= 14)
            {
                question = "血圧を下げてくれる食べ物は？";
                options = new string[] { "チョコレート", "米粉", "くず粉", "きな粉" };
                Answer = "きな粉";
            }
            else if (playerPoints >= 12)
            {
                question = "大根に簡単に味を染み込ませる方法は？";
                options = new string[] { "電子レンジで加熱", "氷水に漬ける", "新聞紙に包む", "土に埋める" };
                Answer = "電子レンジで加熱";
            }
            else if (playerPoints >= 10)
            {
                question = "第1次南極観測隊が航海に連れて行った動物は？";
                options = new string[] { "ねこ", "犬", "からす", "あざらし" };
                Answer = "犬";
            }
            else if (playerPoints >= 8)
            {
                question = "昭和の学校給食でよく出ていた肉は何の肉でしょうか？";
                options = new string[] { "うさぎ", "くじら", "いのしし", "はと" };
                Answer = "くじら";
            }
            else if (playerPoints >= 6)
            {
                question = "昭和33年に完成した、東京の観光名所の名前は？";
                options = new string[] { "東京ディズニーランド", "東京ドーム", "としまえん", "東京タワー" };
                Answer = "東京タワー";
            }
            else if (playerPoints >= 4)
            {
                question = "日本で最も大きな仏像は何でしょうか？";
                options = new string[] { "牛久大仏", "鎌倉大仏", "仙台大観音", "東大寺盧舎那仏像" };
                Answer = "牛久大仏";
            }
            else if (playerPoints >= 2)
            {
                question = "日本の木造の建造物で一番古いものは何でしょうか？";
                options = new string[] { "金閣寺", "清水寺", "法隆寺", "銀閣寺" };
                Answer = "法隆寺";
            }

            else
            {
                question = "現在使われている消しゴムは何でできているでしょうか?";
                options = new string[] { "ゴム", "ウレタン", "ナイロン", "プラスチック" };
                Answer = "ゴム";
            }
            


                questionLabel.Text = question;
                button1.Text = options[0];
                button2.Text = options[1];
                button3.Text = options[2];
                button4.Text = options[3];
            }
        private void button_Click(object sender, EventArgs e)
        {
            // ボタンのクリックイベント
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                string selectedAnswer = clickedButton.Text;

                // 正解判定
                if (selectedAnswer == Answer)
                {
                    MessageBox.Show("正解です！", "結果", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    seikaiSoundPlayer.Play();
                }
                else
                {
                    MessageBox.Show($"不正解です。正解は「{Answer}」です。", "結果", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    fuseikaiSoundPlayer.Play();
                }
               
                
                this.Close();
            }


        }
    }
}
