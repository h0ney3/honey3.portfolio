﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace モグラたたき
{
    public partial class Form1 : Form
    {
        private Label Pointlavel;
        private Label Count;
        private Point molePosition;
        int count;
        int posision;
        bool click;
        //画像のリスト
        private List<Image> moleImages;
        private List<int> Points;
        private List<int> Weights;
        private Random random = new Random();
        private int currentPoints = 0;
        private SoundPlayer soundPlayer;
        private SoundPlayer mainasuSound;

        public Form1()
        {
            InitializeComponent();
            InitializeMoleImages();  //画像のリストを初期化
            soundPlayer = new SoundPlayer("maou_se_system44.wav");
            mainasuSound = new SoundPlayer("maou_se_system47.wav");
            picture.Click += picture_Click;
            if (Pointlavel == null)
            {
                Pointlavel = new Label();
                Pointlavel.Location = new Point(10, 10);
                Pointlavel.Text = "0";
                this.Controls.Add(Pointlavel);
            }
            if (Count == null)
            {
                Count = new Label();
                Count.Location = new Point(180, 110);
                Count.Visible = false;
                this.Controls.Add(Count);
            }
        }
        private void InitializeMoleImages()
        {
            //画像を読み込む
            moleImages = new List<Image>
            {
                Properties.Resources.fruits_basket, 
                Properties.Resources.shinkai_mariana_snailfish,
                Properties.Resources.animal_mogura,
                Properties.Resources.animal_mogura_kouji2,
                Properties.Resources.apple_doku_ringo,
                //画像をランダムに表示
            };
            Points = new List<int>
            {
                1,  // fruits_basketのポイント
                2,   // shinkai_mariana_snailfishのポイント
                3,  //animal_moguraのポイント
                5,  //animal_mogura_kouji2ポイント
                -3,  // apple_doku_ringo,ポイント
            };
            Weights = new List<int>
            {
                7,  // fruits_basketの出現率
                2,  // shinkai_mariana_snailfishの出現率
               3,  //animal_moguraの出現率
               1,  //animal_mogura_kouji2の出現率
               2,  //apple_doku_ringo,の出現率
            };
        }
        private int GetRandomWeightedIndex()
        {
            // 重みの合計を計算
            int totalWeight = Weights.Sum();
            int randomValue = random.Next(totalWeight);

            // 重みに応じて選択される
            int sum = 0;
            for (int i = 0; i < Weights.Count; i++)
            {
                sum += Weights[i];
                if (randomValue < sum)
                    return i;
            }
            return 0;
        }

        private void end_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Pointlavel.Text = "0";
            count = 0;
            click = false;
           
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
          Levellavel.Text = hScrollBar1.Value.ToString();
        }

        private void start_Click(object sender, EventArgs e)
        {
            Form1_Load(null, null);
            ControlsEnableChange();
            timer1.Interval = (1000 - hScrollBar1.Value * 30);
            timer1.Enabled = true;
            picture.Visible = true;
            Count.Text = "";
            Count.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(count == 15)
            {
                timer1.Enabled = false;
                ControlsEnableChange();
                picture.Visible = false;
                Count.Font = new Font("Arial", 17, FontStyle.Bold);
                Count.Text = "終了❕";
                Count.Visible = true;
                Form2 form2 = new Form2();
                form2.SetPoints(Convert.ToInt32(Pointlavel.Text)); 
                form2.Show();
                return;
            }
            //画像の位置更新
            molePosition = pointpickup();
            picture.Location = molePosition;

            //画像をランダムに選択して表示
            int selectedIndex = GetRandomWeightedIndex();
            picture.Image = moleImages[selectedIndex];
            currentPoints = Points[selectedIndex];  // 現在のポイント更新


            picture.Visible = true;
            click = false;
            count++;

        }
        

        private Point pointpickup()
        {
            posision += random.Next(1, 11);
            molePosition = new Point(12 + (posision % 4) * 125, 30 + (posision % 3) * 150);
            return molePosition;
        }

        private void picture_Click(object sender, EventArgs e)
        {
            if (click == false)
            {
                Pointlavel.Text = (Convert.ToInt32(Pointlavel.Text) + currentPoints).ToString();
                click = true;

                if (currentPoints < 0)
                {
                    soundPlayer.Play();
                }
                else
                {
                    mainasuSound.Play(); // プラス用効果音
                }

            }
        }
        private void ControlsEnableChange()
        {
            start.Enabled = !start.Enabled;
            end.Enabled = !end.Enabled;
            hScrollBar1.Enabled = !hScrollBar1.Enabled;
        }
    }
}
